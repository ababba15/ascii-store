import React, { Component } from 'react';
import { View } from 'react-native';
import { Provider } from 'react-redux';
import { SpinnerOverlay } from 'molecules';
import { MainDrawer, AuthStack } from 'navigators/MainNavigator';
import store from 'store';
import { connect } from 'react-redux';
import types from 'constants';

class App extends Component {
    componentWillMount() {
        const { dispatch } = this.props;
        dispatch({ type: types.INITIAL_ACTIONS });
    }

    render() {
        return this.props.loggedIn ? <MainDrawer {...this.props} /> : <AuthStack />;
    }
}
const select = (state) => ({
    loggedIn: state.loggedIn
});
const ConnectedApp = connect(select)(App);

const AppWithOverlay = (props) => (
    <View style={{ width: '100%', height: '100%' }}>
        <ConnectedApp />
        {/* <SpinnerOverlay modalVisible={props.overlay} /> */}
    </View>
);

const select_2 = (state) => ({
    overlay: state.overlay
});
const ConnectedAppWithOverlay = connect(select_2)(AppWithOverlay);

const Root = () => (
    <Provider store={store}>
        <ConnectedAppWithOverlay />
    </Provider>
);

export default Root;

console.ignoredYellowBox = ['Warning: BackAndroid'];