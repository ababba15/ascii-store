import { NavigationActions } from 'react-navigation';

export const goTo = (props, routeName, params = {}) => {
    const navAction = NavigationActions.navigate({ routeName, params });
    return props.navigation.dispatch(navAction);
};

export const resetTo = (props, routeName, params = {}) => {
    const resetAction = NavigationActions.reset({
        actions: [NavigationActions.navigate({ routeName, params })],
        index: 0
    });
    props.screenProps.navigation.dispatch(resetAction);
    // goTo(props, 'Loading');
    // setTimeout(() => {
    // props.screenProps.navigation.dispatch(resetAction);
    // }, 1000);
};

export const goBack = (props, routeName, params = {}) => {
    return props.navigation.goBack();
};