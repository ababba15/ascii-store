export const config = {
    baseUrl: 'https://onpoint.co.nz/api/v1'
    // baseUrl: 'http://onpoint.mitri4.pro/api/v1'
};
