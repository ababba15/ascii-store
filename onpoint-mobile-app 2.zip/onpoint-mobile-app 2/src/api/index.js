import Repoint from 'repoint';
import { config } from 'utils';

const responseHandler = (response) => {
    if (response.status === 200 || response.status === 201) {
        return new Promise(resolve => {
            response.json().then(data => {
                resolve({ ...data, error: null });
            }).catch(error => resolve({ response: null, error }));
        });
    }
    return response.json();
};

const beforeError = (response, body) => {
    if (response.status === 204) {
        response._bodyInit = '{"data":{}}';
        response._bodyText = '{"data":{}}';
    }

    if (response.status === 401) {
        response._bodyInit = '{"data":{},"errors":{}}';
        response._bodyText = '{"unauthorized": "true"}';
    }

    if (response.status === 402) {
        response._bodyInit = '{"data":{},"errors":{"message":"error message here"}}';
    }

    if (response.status === 500) {
        response._bodyInit = '{"errors":{"message":"A server error occurred. Please try again later."}}';
    }

    return response;
};

const _config = {
    host: config.baseUrl
    //   paramsTransform: (data) => decamelizeKeys(data),
    //   beforeSuccess: (data) => camelizeKeys(data),
    // beforeError,
    // responseHandler
};

const repoint = new Repoint(_config);

export const loginAPI = repoint.generate('accounts/login/', { singular: true });
export const logoutAPI = repoint.generate('accounts/logout/', { singular: true });
export const resetAPI = repoint.generate('accounts/password_reset/', { singular: true });

export const eventsAPI = repoint.generate('events/', { singular: true });
export const ticketsAPI = repoint.generate('orders', { idAttribute: 'id' });