import types from 'constants';
import _ from 'underscore';

const generatedReducers = _.mapObject(types, (type, key) => {
    return (state = {}, action) => {
        switch (action.type) {
            case type:
                return {
                    ...state,
                    ...action.payload
                };
            default:
                return state;
        }
    };
});

export default generatedReducers;