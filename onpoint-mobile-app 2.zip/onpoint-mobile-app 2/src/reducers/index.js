import { combineReducers } from 'redux';

// reducers
// import generatedReducers from './reducerCreator';
import spinner from './spinner';
import overlay from './overlay';
import loggedIn from './loggedIn';
import events from './events';
import tickets from './tickets';


export default combineReducers({
    // ...generatedReducers,
    spinner,
    overlay,
    loggedIn,
    events,
    tickets
});