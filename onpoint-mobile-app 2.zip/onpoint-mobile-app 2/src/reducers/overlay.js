export default (state = false, action) => {
    switch (action.type) {
        case 'OVERLAY':
            return action.payload;
        default:
            return state;
    }
};