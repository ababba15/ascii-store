export default (state = false, action) => {
    switch (action.type) {
        case 'GET_EVENTS_SUCCESS':
            return action.payload;
        default:
            return state;
    }
};