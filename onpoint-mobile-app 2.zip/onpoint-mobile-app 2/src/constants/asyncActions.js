export default [
    'USER_LOGIN',
    'GET_TOKEN',
    'USER_REGISTER',
    'PASSWORD_RESET',
    'GET_EVENTS',
    'GET_TICKETS',
    'UPDATE_TICKET_WS'
];