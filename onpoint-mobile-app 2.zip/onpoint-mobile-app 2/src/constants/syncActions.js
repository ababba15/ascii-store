export default [
    'LOADING_MESSAGE',
    'SPINNER',
    'INITIAL_ACTIONS',
    'OVERLAY',
    'SOCKET',
    'UPDATE_TICKET'
];