import React from 'react';
import { StackNavigator, DrawerNavigator } from 'react-navigation';
import { NavHeader, DrawerMenu } from 'molecules';
import { ScannerScreen, EventsScreen, TicketsScreen, LoginScreen, PassRecoveryScreen, TicketScreen } from 'screens';


export const AuthStack = StackNavigator({
    Login: {
        screen: (props) => <LoginScreen {...props} />,
        navigationOptions: {
            headerMode: 'none'
        }
    },
    PassRecovery: {
        screen: (props) => <PassRecoveryScreen {...props} />,
        navigationOptions: {
            headerMode: 'none'
        }
    }
}, {
    headerMode: 'none',
    mode: 'modal',
    initialRouteName: 'Login'
});

export const MainDrawer = DrawerNavigator({
    AppStack: {
        screen: (props) => <AppStack screenProps={props} />
    }
}, {
    contentComponent: (props) => <DrawerMenu screenProps={props} />,
    drawerPosition: 'right'
});

const AppStack = StackNavigator({
    EventsScreen: {
        screen: (props) => <EventsScreen {...props} />
    },
    ScannerStack: {
        screen: (props) => <ScannerStack screenProps={props.navigation} />
    }
}, {
    navigationOptions: {
        header: (props) => <NavHeader {...props} />
    }
});

const ScannerStack = StackNavigator({
    ScannerScreen: {
        screen: (props) => <ScannerScreen {...props}  />
    },
    TicketsScreen: {
        screen: (props) => <TicketsScreen screenProps={props.navigation} {...props} />
    },
    TicketScreen: {
        screen: (props) => <TicketScreen screenProps={props.navigation} {...props} />
    }
}, {
    mode: 'modal',
    headerMode: 'none',
    navigationOptions: {
        header: () => <NavHeader subRoute />
    }
});