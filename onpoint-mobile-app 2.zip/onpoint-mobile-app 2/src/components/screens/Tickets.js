import React, { PureComponent } from 'react';
import { View, Text, TouchableOpacity, FlatList, Image, StyleSheet, StatusBar } from 'react-native';
import { ListRowTickets } from 'molecules';
import store from 'store';
import { connect } from 'react-redux';
import { NavigationActions } from 'react-navigation';
import _ from 'underscore';


class TicketsScreen extends PureComponent {
    constructor(props) {
        super(props);
        this.eventId = props.screenProps.state.params.eventId;
    }

    _goScanner = () => {
        this.props.navigation.goBack();
    }

    _goTicket = (uid) => {
        const { tickets, events } = this.props;
        const ticket = _.filter(tickets[this.eventId], { uid });
        const event = _.filter(events, { pk: this.eventId });
        const eventImgUrl = event[0].artist_image;
        const navigateAction = NavigationActions.navigate({
            routeName: 'TicketScreen',
            params: { ticket: { ...ticket[0], eventImgUrl } }
        });
        this.props.navigation.dispatch(navigateAction);
    }

    render() {
        return (
            <View>
                <StatusBar barStyle='light-content' />
                <TouchableOpacity
                    style={s.btnThinContainer}
                    onPress={this._goScanner}>
                    <Text style={s.btnText} sz={14}>Back to scanner</Text>
                    <Image style={s.btnIcon} source={require('icons/minus.png')} />
                </TouchableOpacity>
                <View style={s.listWrap}>
                    <FlatList
                        keyExtractor={it => it.uid}
                        ListEmptyComponent={() => <Text>No tickets found in this event..</Text>}
                        style={{ height: '96.3%' }}
                        data={this.props.tickets[this.eventId]}
                        extraData={this.props.tickets[this.eventId]}
                        renderItem={({ item }) => <ListRowTickets {...item} onPress={() => this._goTicket(item.uid)} />} />
                </View>
            </View>
        );
    }
}

const s = StyleSheet.create({
    btnThinContainer: {
        height: 48,
        zIndex: 2,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        width: '100%',
        backgroundColor: '#000',
        borderBottomWidth: .5,
        borderColor: '#414141'
    },
    btnText: {
        zIndex: 3,
        color: 'white',
        backgroundColor: 'transparent'
    },
    btnIcon: {
        height: 14,
        width: 14,
        marginHorizontal: 7,
        resizeMode: 'contain'
    },
    listWrap: {
        backgroundColor: '#272727',
        width: '100%',
        height: '92%'
    }
});

const select = (state) => ({
    tickets: state.tickets,
    events: state.events
});

const ConnectedTicketsScreen = connect(select)(TicketsScreen);

export default ConnectedTicketsScreen;