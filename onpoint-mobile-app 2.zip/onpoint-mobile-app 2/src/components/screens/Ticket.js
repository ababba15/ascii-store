import React, { PureComponent } from 'react';
import { View, ScrollView, Text, TouchableOpacity, TouchableWithoutFeedback, Image, StyleSheet, StatusBar } from 'react-native';

class TicketScreen extends PureComponent {
    constructor(props) {
        super(props);
        this.ticket = props.navigation.state.params.ticket;
        console.log(this.ticket);
    }

    goBack = () => {
        this.props.navigation.goBack();
    }

    render() {
        const {
            client_email,
            client_username,
            event_date,
            event_time,
            event_name,
            event_city,
            is_used,
            uid,
            eventImgUrl
        } = this.ticket;
        return (
            <View>
                <StatusBar barStyle='light-content' />
                <ScrollView>
                    <View style={s.imageContainer}>
                        <TouchableWithoutFeedback onPress={this.goBack}>
                            <Image style={s.image} source={{ uri: eventImgUrl }} />
                        </TouchableWithoutFeedback>
                        {
                            is_used ?
                                <View style={s.statusContainer}>
                                    <Image style={s.statusIcon} source={require('icons/ticket_status_ok.png')} />
                                    <Text style={s.statusText}>TICKET REGISTERED</Text>
                                </View>
                            :
                                <View style={[ s.statusContainer, { backgroundColor: '#aeaeae' }]}>
                                    <Text style={s.statusText}>TICKET NOT REGISTERED</Text>
                                </View>
                        }
                    </View>
                    <View style={s.infoContainer}>
                        <Text style={s.uid}>#{uid}</Text>
                        <View style={s.topInfoBlock}>
                            <View>
                                <Text style={s.eventName}>{event_name}</Text>
                                <Text style={s.eventPlace}>{event_city}</Text>
                                <Text style={s.eventTime}>{event_date}, {event_time}</Text>
                            </View>
                            <Image style={s.qr} source={require('assets/qr_code.png')} />
                        </View>
                        <View style={s.bottomInfoBlock}>
                            <View>
                                <Text style={s.title}>Email</Text>
                                <Text style={s.value}>{client_email}</Text>
                            </View>
                            <View>
                                <Text style={s.title}>Name</Text>
                                <Text style={s.value}>{client_username}</Text>
                            </View>
                        </View>
                        <TouchableOpacity
                            style={s.btn}
                            onPress={this.goBack}>
                            <Text>
                            SCAN NEW TICKET
                        </Text>
                        </TouchableOpacity>
                    </View>
                </ScrollView>
            </View>
        );
    }
}

const s = StyleSheet.create({
    imageContainer: {
        height: 240,
        width: '100%'
    },
    image: {
        height: 240,
        width: '100%'
    },
    statusContainer: {
        backgroundColor: '#43FFA1',
        position: 'absolute',
        height: 50,
        // width: '70%',
        // top: 240 + 25,
        bottom: -25,
        zIndex: 20,
        alignSelf: 'center',

        alignItems: 'center',
        justifyContent: 'center',
        flexDirection: 'row',

        borderRadius: 25,

        elevation: 6,
        shadowRadius: 10,
        shadowOpacity: .15,
        shadowOffset: {
            width: 0,
            height: 5
        },
        shadowColor: 'black'
    },

    statusIcon: {
        width: 18,
        height: 18,
        marginLeft: 22
    },
    statusText: {
        fontWeight: '500',
        marginHorizontal: 22
    },

    infoContainer: {
        padding: 25,
        paddingTop: 35
    },

    topInfoBlock: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginTop: 20
    },
    bottomInfoBlock: {
        // flexDirection: 'row',
        // justifyContent: 'space-between',
        marginVertical: 10
    },
    uid: {
        backgroundColor: 'transparent',
        color: '#F33363',
        fontSize: 14,
        fontWeight: '700',
        textAlign: 'center'
    },
    eventName: {
        backgroundColor: 'transparent',
        fontSize: 26,
        marginBottom: 8
    },
    eventPlace: {
        backgroundColor: 'transparent',
        fontSize: 16
    },
    eventTime: {
        backgroundColor: 'transparent',
        fontSize: 16
    },
    qr: {
        width: 115,
        height: 115
    },
    title: {
        backgroundColor: 'transparent',
        fontSize: 14,
        color: '#9B9B9B',
        marginTop: 10
    },
    value: {
        backgroundColor: 'transparent',
        fontSize: 18
    },

    btn: {
        borderWidth: 2,
        borderColor: '#9B9B9B',
        height: 50,
        width: '100%',
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 20
    }
});

export default TicketScreen;