import React, { Component } from 'react';
import { StyleSheet, View, Image, TouchableOpacity, Dimensions, StatusBar, Platform } from 'react-native';
import { NavigationActions } from 'react-navigation';
import { TicketScanResult } from 'molecules';
import { Text } from 'atoms';
import Camera from 'react-native-camera';
import { connect } from 'react-redux';
import Sound from 'react-native-sound';

Sound.setCategory('Playback');

const { width } = Dimensions.get('screen');

// Sounds
const scan = new Sound('scan.wav', Sound.MAIN_BUNDLE);
const scanError = new Sound('scan_error.wav', Sound.MAIN_BUNDLE);

class Scanner extends Component {
    constructor(props) {
        super(props);
        this.eventId = props.screenProps.state.params.eventId;
        this.state = {
            currentEventTickets: props.tickets[this.eventId],
            computedTicketData: {},
            status: 'scanning',
            modalVisible: false
        };
    }

    _goTickets = () => {
        const navigateAction = NavigationActions.navigate({
            routeName: 'TicketsScreen',
            params: { eventId: this.eventId }
        });
        this.props.navigation.dispatch(navigateAction);
    }

    _handleCode = (e) => {
        const data = this._computeTicketData(e.data);
        const { dispatch } = this.props;

        if (!Object.keys(data).length) {
            scanError.play();
            this.setState({
                status: 'not_found',
                modalVisible: true
            });
            return;
        } else if (data.is_used) {
            scanError.play();
            this.setState({
                status: 'is_used',
                modalVisible: true
            });
        } else {
            // TIcket is ok
            scan.play();
            dispatch({
                type: 'SOCKET',
                sendMessage: true,
                payload: {
                    uid: data.uid,
                    eventId: this.eventId
                }
            });

            this.setState({
                status: 'ok',
                computedTicketData: data
            }, () => {
                setTimeout(() => {
                    this.setState({
                        status: 'scanning',
                        computedTicketData: {}
                    });
                }, 1500);
            });
        }
        return;
    }

    handleCloseModal = () => {
        this.setState({
            status: 'scanning',
            modalVisible: false
        });
    }

    _computeTicketData(uid) {
        let result = '';
        this.props.tickets[this.eventId].forEach((item) => {
            if (item.uid.replace(/-/g, '') === uid) {
                result = item;
            }
        });
        return result || {};
    }

    render() {
        console.log(this.state.status);
        return (
            <View style={s.scanner}>
                <StatusBar barStyle='light-content' />
                <View renderToHardwareTextureAndroid shouldRasterizeIOS style={s.container}>
                    <View style={s.previewContainer}>
                        <Camera
                            ref={ref => this.camera = ref}
                            style={s.previewWindow}
                            captureQuality='160p'
                            aspect='fill'
                            // flashMode='on'
                            // torchMode='on'
                            orientation='portrait'
                            // captureMode='video'
                            // captureTarget='disk'
                            onBarCodeRead={(this.state.status === 'scanning') ? this._handleCode : (() => {})} />
                        <View style={s.previewTextContainer}>
                            <Text sz={16} style={s.previewCodeText}>{this.state.status === 'scanning' ? 'Scanning..' : '<<<<<<<<<'}</Text>
                            <Image style={s.previewCodeIcon} source={require('icons/codewh.png')} />
                        </View>
                    </View>
                </View>
                <View renderToHardwareTextureAndroid shouldRasterizeIOS style={s.statusContainer}>
                    <TouchableOpacity
                        style={s.btnThinContainer}
                        onPress={this._goTickets}>
                        <Text style={s.btnText} sz={14}>View all is_used tickets</Text>
                        <Image style={s.btnIcon} source={require('icons/plus.png')} />
                    </TouchableOpacity>
                    <View style={s.statusInfoContainer}>
                        {(this.state.status === 'ok') ?
                            <View style={s.innerContainer}>
                                <View>
                                    <Text sz={22} style={s.username}>{this.state.computedTicketData.client_username}</Text>
                                    <Text sz={16} style={s.statusEmail}>{this.state.computedTicketData.client_email}</Text>
                                </View>
                                <Image style={s.statusIcon} source={require('icons/ok.png')} />
                            </View>
                            :
                            <View style={s.innerContainer}>
                                <View>
                                    <Text sz={22} style={s.username}>Looking for ticket...</Text>
                                    <Text sz={16} style={s.statusEmail}>Put a barcode into camera view</Text>
                                </View>
                                <Image style={s.statusIcon} source={require('icons/search.png')} />
                            </View>
                    }
                    </View>
                </View>
                <TicketScanResult
                    close={this.handleCloseModal}
                    modalVisible={this.state.modalVisible} status={this.state.status} />
            </View>
        );
    }
}

const mapStateToProps = (state) => {
    // console.log('state.storeTickets', state.storeTickets);
    return {
        tickets: state.tickets
    };
};

export default connect(mapStateToProps)(Scanner);


const s = StyleSheet.create({
    scanner: {
        flex: 1,
        alignItems: 'center'
    },
    container: {
        padding: 20,
        backgroundColor: '#F0F0F0'
    },

    // Preview
    previewContainer: {
        position: 'relative',
        width: width - 30,
        height: 420
    },
    previewWindow: {
        borderWidth: .5,
        borderColor: '#7E7E7E',
        position: 'absolute',
        right: 0,
        width: width - 30 - 40,
        height: Platform.OS === 'ios' ? 420 : 250
        // width: 100,
        // height: 100
    },
    previewTextContainer: {
        position: 'absolute',
        justifyContent: 'flex-end',
        alignItems: 'center',
        flexDirection: 'row',
        paddingHorizontal: 20,
        transform: [
            { 'rotate': '-90deg' },
            { translateY: -105 },
            { translateX: -105 }
        ],
        // top: 250,
        // left: 0,
        backgroundColor: 'black',
        height: 40,
        width: 250
    },
    previewCodeIcon: {
        height: 24,
        width: 24,
        marginLeft: 10
    },
    previewCodeText: {
        bottom: 0
    },

    // Scan status
    statusContainer: {
        backgroundColor: 'black',
        alignSelf: 'stretch',
        position: 'absolute',
        bottom: 0,
        width: '100%'
    },
    statusIcon: {
        height: 36,
        width: 36
    },
    statusInfoContainer: {
        padding: 30
    },
    innerContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        height: 37
    },

    // button "View all is_used tickets"
    btnThinContainer: {
        height: 48,
        zIndex: 2,
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        width: '100%',
        backgroundColor: '#000',
        borderBottomWidth: .5,
        borderColor: '#414141'
    },
    btnText: {
        zIndex: 3,
        color: 'white',
        backgroundColor: 'transparent'
    },
    btnIcon: {
        height: 14,
        width: 14,
        marginHorizontal: 7
    }
});