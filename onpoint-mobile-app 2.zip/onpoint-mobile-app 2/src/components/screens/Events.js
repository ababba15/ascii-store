import React, { Component } from 'react';
import { View, Text, StatusBar } from 'react-native';
import { FlatList } from 'react-native';
import { ListRowEvents, Separator, SpinnerOverlay } from 'molecules';
import { connect } from 'react-redux';
import { NavigationActions } from 'react-navigation';

class EventsScreen extends Component {

    constructor(props) {
        super(props);
        this.state = {
            listReady: true,
            loading: true,
            dataSource: []
        };
    }

    // componentDidMount() {
    //     const { dispatch } = this.props;
    //     setTimeout(() => {
    //         dispatch({
    //             type: 'SOCKET',
    //             sendMessage: true,
    //             payload: {
    //                 uid: 'e2e191d2-3387-45aa-ac64-e9d9638cc0c7',
    //                 eventId: 10
    //             }
    //         });
    //     }, 6000);
    // }

    componentWillReceiveProps(nextProps) {
        const { events } = nextProps;
        if (events) {
            this.setState({
                listReady: true,
                loading: false
            });
        }
    }

    _getTickets = (pk) => {
        const { dispatch } = this.props;
        dispatch({
            type: 'GET_TICKETS_REQUEST',
            payload: pk
        });
    }

    _goToScanner = (pk) => {
        const goToScanner = NavigationActions.navigate({
            routeName: 'ScannerStack',
            params: { eventId: pk }
        });
        this.props.navigation.dispatch(goToScanner);
    }

    render() {
        return (
            <View>
                <StatusBar barStyle='light-content' />
                <FlatList
                    style={{ height: '100%' }}
                    ListEmptyComponent={() => <Text>No events for now..</Text>}
                    data={this.props.events}
                    ItemSeparatorComponent={Separator}
                    keyExtractor={it => it.pk}
                    renderItem={({ item }) =>
                        <ListRowEvents
                            {...item}
                            getTickets={() => this._getTickets(item.pk)}
                            hasTickets={this.props.tickets[item.pk]}
                            goToScanner={() => this._goToScanner(item.pk)} />
                        }
                    />
            </View>
        );
    }
}

const select = (store) => ({
    events: store.events,
    tickets: store.tickets,
    overlay: store.overlay
});

export default connect(select)(EventsScreen);