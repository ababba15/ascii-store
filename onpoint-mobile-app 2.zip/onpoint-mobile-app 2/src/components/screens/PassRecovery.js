import React, { Component } from 'react';
import { View, ScrollView, TouchableOpacity, StyleSheet, StatusBar, Image } from 'react-native';
import { post } from 'api';
import { Input, Button, Text } from 'atoms';
import { Toast } from 'molecules';

export default class Login extends Component {
    constructor(props) {
        super(props);
        this.state = {
            email: ''
        };
    }

    _handleEmail = (email) => {
        this.setState({ email });
    }

    _handleSubmit = () => {
        const email = this.state.email;
        post('/accounts/password_reset/', { email }, () => { this._goBack(); });
    }

    _goBack = () => {
        const { goBack } = this.props.navigation;
        goBack(null);
    }

    render() {
        return (
            <View style={s.container}>
                <Toast ref={(ref) => this.toast = ref} backed />
                <ScrollView contentContainerStyle={s.container}>
                    <StatusBar barStyle='light-content' />
                    <Image style={s.logo} source={{ uri: 'logo' }} />
                    <Text sz={30} style={{ marginBottom: 22 }}>
                        Restore password
                    </Text>
                    <Input
                        placeholder='email'
                        value={this.state.email}
                        keyboardType='email-address'
                        onChangeText={this._handleEmail} />
                    <Button onPress={this._handleSubmit} style={{ marginTop: 30 }}>
                        SUBMIT
                    </Button>
                    <TouchableOpacity onPress={this._goBack} style={{ marginVertical: 150 }}>
                        <Text sz={14} style={{ textDecorationLine: 'underline' }}>
                            Sign in
                        </Text>
                    </TouchableOpacity>
                </ScrollView>
            </View>
        );
    }
}


const s = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#000',
        alignItems: 'center',
        justifyContent: 'center'
    },
    logo: {
        width: 200,
        height: 60,
        marginBottom: 65,
        top: 25,
        resizeMode: 'contain'
    }
});