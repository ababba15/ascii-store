import React, { Component } from 'react';
import { View, ScrollView, StyleSheet, StatusBar, Image, TouchableOpacity, ActivityIndicator } from 'react-native';
import { NavigationActions } from 'react-navigation';
import { Input, Button, Text } from 'atoms';
import { Agree, Toast } from 'molecules';
import types from 'constants';
import { connect } from 'react-redux';
import { resetTo } from 'utils';

// import { NativeModules } from 'react-native';

// console.log(NativeModules.P2P);
// NativeModules.P2P.toggle();

class Login extends Component {
    constructor(props) {
        super(props);
        this.state = {
            email: '',
            password: '',
            checked: false,
            wrongEmail: false,
            wrongPassword: false
        };
    }

    _handleEmail = (email) => {
        this.email.animateAlert(0);
        this.setState({ email });
    }

    _handlePassword = (password) => {
        this.password.animateAlert(0);
        this.setState({ password });
    }

    _handleCheckbox = () => {
        this.setState({ checked: !this.state.checked });
    }

    _goPassRecovery = () => {
        const navigateAction = NavigationActions.navigate({ routeName: 'PassRecovery' });
        this.props.navigation.dispatch(navigateAction);
    }

    _handleSubmit = () => {
        const { email, password, checked } = this.state;
        const { dispatch } = this.props;

        this.setState({
            wrongEmail: email.indexOf('@') < 1,
            wrongPassword: !password
        }, () => {
            if (this.state.wrongEmail) {
                // this.toast.showTimed('Enter a valid email, please', 4000);
                this.email.animateAlert(1);
                return;
            }

            if (this.state.wrongPassword) {
                // this.toast.showTimed('Enter your password, please', 4000);
                this.password.animateAlert(1);
                return;
            }

            dispatch({
                type: types.USER_LOGIN_REQUEST,
                payload: this.state,
                props: this.props
            });
        });
    }

    render() {
        return (
            <View style={s.container}>
                <Toast ref={(ref) => this.toast = ref} backed />
                <ScrollView
                    showsHorizontalScrollIndicator={false}
                    showsVerticalScrollIndicator={false}
                    contentContainerStyle={s.scrollContainer}>
                    <StatusBar barStyle='light-content' />
                    <Image style={s.logo} source={require('assets/logotxt.png')} />
                    <Text sz={30} style={{ marginBottom: 22 }}>
                        SIGN IN
                    </Text>
                    <Input
                        placeholder='Email address'
                        ref={ref => this.email = ref}
                        value={this.state.email}
                        keyboardType='email-address'
                        subAlert='This value should be a valid email.'
                        onChangeText={this._handleEmail} />
                    <Input placeholder='Password'
                        value={this.state.password}
                        ref={ref => this.password = ref}
                        subAlert="Password can't be empty."
                        secureTextEntry
                        onChangeText={this._handlePassword} />
                    <Agree onPress={this._handleCheckbox} checked={this.state.checked} />
                    <Button loading={this.props.loading} onPress={this._handleSubmit} style={{ marginTop: 10 }}>
                        SIGN IN
                    </Button>
                    <TouchableOpacity onPress={this._goPassRecovery} style={{ marginVertical: 50 }}>
                        <Text sz={14} style={{ textDecorationLine: 'underline' }}>
                            Forgot password
                        </Text>
                    </TouchableOpacity>
                </ScrollView>
            </View>
        );
    }
}


const s = StyleSheet.create({
    container: {
        backgroundColor: '#000',
        alignItems: 'center',
        justifyContent: 'center',
        width: '100%',
        height: '100%'
    },
    scrollContainer: {
        alignItems: 'center',
        justifyContent: 'center',
        width: '100%',
        height: '100%'
    },
    logo: {
        width: 200,
        height: 60,
        marginBottom: 45,
        top: 25,
        resizeMode: 'contain'
    }
});

const dataStore = (store) => ({
    loading: store.spinner.loginButton
});


export default connect(dataStore)(Login);