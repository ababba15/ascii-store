import React, { Component } from 'react';
import { View, Text,  TextInput, StyleSheet, Dimensions, Animated } from 'react-native';

export default class extends Component{
    constructor() {
        super();
        this.state = {
            width: Dimensions.get('screen').width
        };

        this.placeholderAnimated = new Animated.Value(0);
        this.alertAnimated = new Animated.Value(0);
    }

    layout = () => {
        this.setState({
            width: Dimensions.get('screen').width
        });
    };

    animatePlaceholder = (toValue) => {
        Animated.spring(this.placeholderAnimated, { toValue }).start();
    }

    animateAlert = (toValue) => {
        Animated.spring(this.alertAnimated, { toValue }).start();
    }

    render() {
        const anTop = this.placeholderAnimated.interpolate({
            inputRange: [ 0, 1 ],
            outputRange: [ 18, 10 ],
            extrapolate: 'clamp'
        });

        const anFontSize = this.placeholderAnimated.interpolate({
            inputRange: [ 0, 1 ],
            outputRange: [ 18, 12 ],
            extrapolate: 'clamp'
        });

        const anAlertOpacity = this.alertAnimated.interpolate({
            inputRange: [ 0, 1 ],
            outputRange: [ 0, 1 ],
            extrapolate: 'clamp'
        });

        return (
            <View onLayout={this.layout}>
                <View style={[ s.inputContainer, { width: this.state.width - 30 }]}>
                    <TextInput {...this.props}
                        placeholder=''
                        style={[ s.input, { width: this.state.width - 30 }]}
                        value={this.props.value}
                        spellCheck={false}
                        autocorrect={false}
                        autoCapitalize='none'
                        selectionColor='#FF407B'
                        autoCorrect={false}
                        underlineColorAndroid='transparent'
                        onFocus={() => this.animatePlaceholder(1)}
                        onBlur={() => !this.props.value ? this.animatePlaceholder(0) : null}
                        onChangeText={this.props.onChangeText} />
                    <Animated.Text style={[ s.placeholder, {
                        top: anTop,
                        fontSize: anFontSize
                    }]}>{this.props.placeholder}</Animated.Text>

                </View>
                <Animated.Text style={[ s.alert, {
                    opacity: anAlertOpacity
                }]}>{this.props.subAlert}</Animated.Text>
            </View>
        );
    }
}

const s = StyleSheet.create({
    inputContainer: {
        paddingTop: 20,
        backgroundColor: '#fff',
        borderColor: '#EFEFEF',
        borderWidth: .5
        // marginVertical: 20
    },
    input: {
        color: '#000',
        fontSize: 18,
        fontWeight: '300',
        backgroundColor: 'transparent',
        zIndex: 100,
        paddingHorizontal: 20,
        borderWidth: 0,
        borderColor: 'transparent',
        height: 40
    },
    placeholder: {
        position: 'absolute',
        top: 5,
        left: 20,
        fontSize: 12,
        color: '#888',
        backgroundColor: 'transparent'
    },
    alert: {
        color: '#FF0091',
        backgroundColor: 'transparent',
        fontSize: 14,
        opacity: 0,
        marginTop: 5,
        marginBottom: 10
    }
});