import React, { Component } from 'react';
import { TouchableOpacity, StyleSheet } from 'react-native';

export default class Checkbox extends Component {
    constructor(props) {
        super(props);
        this.state = {
            color: 'white'
        };
    }
    componentWillReceiveProps(nextProps) {
        this.setState({
            color: nextProps.checked ? '#FF407B' : 'white'
        });
    }
    render() {
        return (
            <TouchableOpacity onPress={this.props.onPress} style={[s.checkbox, { backgroundColor: this.state.color }]} />
        );
    }
}

const s = StyleSheet.create({
    checkbox: {
        width: 26,
        height: 26,
        borderColor: 'white',
        borderWidth: 4
    }
});