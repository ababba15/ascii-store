import React from 'react';
import { Text } from 'react-native';

export default (props) => (
    <Text style={[style(props), props.style]}>
        { props.children }
    </Text>
);

const style = (props) => ({
    color: props.color || 'white',
    fontSize: props.sz || 16,
    fontWeight: props.fw || '300'
});