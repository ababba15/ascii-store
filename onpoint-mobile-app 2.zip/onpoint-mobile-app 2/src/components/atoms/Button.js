import React from 'react';
import { View, TouchableOpacity, Text, StyleSheet, Dimensions, Image, ActivityIndicator } from 'react-native';

const {width } = Dimensions.get('screen');

export default (props) => (
    <View style={[s.container, { ...props.style }]}>
        <TouchableOpacity style={s.btn} onPress={props.onPress}>
            <Image style={s.btnback} source={require('assets/btnback.png')}>
                {props.loading ?
                    <ActivityIndicator color='#fff' /> :
                    <Text style={s.btntext}>
                        { props.children }
                    </Text>
            }
            </Image>
        </TouchableOpacity>
    </View>
);

const s = StyleSheet.create({
    container: {
        paddingVertical: 0
    },
    btn: {
        height: 50
    },
    btnback: {
        width: width - 30,
        resizeMode: 'cover',
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center'
    },
    btntext: {
        color: 'white',
        fontSize: 18,
        fontWeight: '400',
        width: width - 30,
        textAlign: 'center',
        backgroundColor: 'transparent'
    }
});