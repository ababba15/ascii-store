import React from 'react';
import { View, Image, StyleSheet, Dimensions, TouchableOpacity } from 'react-native';
import { Text } from 'atoms';

const { width } = Dimensions.get('screen');

export const Separator = (sectionId, rowId) => <View sectionId={sectionId} key={rowId} style={s.separator} />;

export default (props) => {
    return (
        <View style={s.container}>
            <View style={s.artist}>
                <Image style={s.artistImg} source={{ uri: props.artist_image }} />
                <Text color='black' sz={20} style={s.artistTitle}>{props.event_title}</Text>
            </View>

            {
            props.hasTickets
            ?
                <TouchableOpacity onPress={(id) => props.goToScanner(id)}>
                    <Image style={s.icon} source={require('icons/code2.png')} />
                </TouchableOpacity>
            :
                <TouchableOpacity onPress={(id) => props.getTickets(id)}>
                    <Image style={s.icon} source={require('icons/getTickets.png')} />
                </TouchableOpacity>
        }
        </View>
    );
};

const s = StyleSheet.create({
    container: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: 20,
        minHeight: 90
    },
    icon: {
        height: 40,
        width: 40,
        resizeMode: 'contain'
    },
    artist: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-start'
    },
    artistImg: {
        width: 50,
        height: 50,
        marginRight: 10,
        borderRadius: 25
        // resizeMode: 'contain'
    },
    artistTitle: {
        maxWidth: width - 140
    },
    separator: {
        alignSelf: 'center',
        height: 1,
        width: width - 20,
        backgroundColor: '#D4D4D4'
    }
});