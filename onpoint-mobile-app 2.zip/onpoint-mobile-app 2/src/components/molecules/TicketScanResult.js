import React from 'react';
import { View, Modal, TouchableOpacity, Text, Image, StyleSheet } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';

export default (props) => {
    return (
        <Modal
            transparent
            style={s.modal}
            animationType='fade'
            onRequestClose={() => null}
            visible={props.modalVisible}>
            <View style={s.centering}>
                <View style={s.modalWrapper}>
                    {props.status === 'not_found' ?
                        <Image style={s.statusIcon} source={require('icons/error.png')} /> :
                    props.status === 'is_used' ?
                        <Image style={s.statusIcon} source={require('icons/question.png')} /> : null
                    }
                    <Image style={s.bgImage} source={require('assets/modal_ticket_bg.png')} />
                    <Text style={s.title}>Oops!</Text>
                    {props.status === 'not_found' ?
                        <Text style={s.text}>This ticket wasn't found.</Text> :
                    props.status === 'is_used' ?
                        <Text style={s.text}>This ticket is already registered.</Text> : null
                    }
                    <Text style={s.text}>Try scanning a new ticket.</Text>
                    <TouchableOpacity style={s.button} onPress={props.close}>
                        <LinearGradient
                            style={s.buttonGradient}
                            colors={[ '#DA2977', '#EC5226' ]}
                            start={{ x: 0, y: .5 }} end={{ x: 1, y: .5 }}>
                            <Text style={s.buttonText}>SCAN ANOTHER TICKET</Text>
                        </LinearGradient>
                    </TouchableOpacity>
                </View>
            </View>
        </Modal>
    );
};

const s = StyleSheet.create({
    modal: {
    },
    centering: {
        backgroundColor: 'rgba(0,0,0,0.8)',
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center'
    },
    modalWrapper: {
        backgroundColor: '#fff',
        width: 320,
        height: 500,
        borderRadius: 20,
        padding: 33,
        alignItems: 'center'
    },
    statusIcon: {
        width: 40,
        height: 40,
        resizeMode: 'contain'
    },
    bgImage: {
        width: 252,
        height: 190,
        resizeMode: 'contain'
    },

    title: {
        fontSize: 26,
        marginVertical: 20
    },
    text: {
        fontSize: 16
    },
    button: {
        width: 200,
        height: 50,
        marginTop: 23
    },
    buttonGradient: {
        width: 200,
        height: 50,
        alignItems: 'center',
        justifyContent: 'center'
    },
    buttonText: {
        fontSize: 15,
        fontWeight: '500',
        color: '#fff',
        backgroundColor: 'transparent'
    }
});