import React from 'react';
import { TouchableOpacity, Text, View, AsyncStorage } from 'react-native';
import { NavigationActions } from 'react-navigation';
import store from 'store';

const DrawerMenu = (props) => {

    const _goToEvents = () => {
        const goToScanner = NavigationActions.navigate({
            routeName: 'EventsScreen'
        });
        props.screenProps.navigation.dispatch(goToScanner);
    };

    return (
        <View style={{ paddingVertical: 30 }}>
            {/* <TouchableOpacity
                style={{
                    paddingHorizontal: 24,
                    paddingVertical: 33
                }}
                onPress={_goToEvents}>
                <Text style={{ fontSize: 18, fontWeight: '600', textAlign: 'right' }}>EVENTS</Text>
            </TouchableOpacity>
            <View
                style={{
                    height: .5,
                    marginHorizontal: 12,
                    borderWidth: .3,
                    borderColor: '#828282'
                }} /> */}
            <TouchableOpacity
                style={{
                    paddingHorizontal: 24,
                    paddingVertical: 33
                }}
                onPress={() => {
                    store.dispatch({ type: 'SOCKET', close: true });
                    store.dispatch({ type: 'USER_LOGIN_SUCCESS', payload: false });
                    AsyncStorage.removeItem('token');
                }}>
                <Text style={{ fontSize: 18, fontWeight: '600', textAlign: 'right' }}>LOGOUT</Text>
            </TouchableOpacity>
        </View>
    );
};

export default DrawerMenu;