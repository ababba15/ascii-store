import React from 'react';
import { View, StyleSheet, Dimensions } from 'react-native';
import { Checkbox, Text } from 'atoms';

const { width } = Dimensions.get('screen');

export default (props) => (
    <View style={s.container}>
        <Checkbox onPress={props.onPress} checked={props.checked} />
        <Text sz={18} style={{marginLeft: 10}}>Remember me on this device</Text>
    </View>
);

const s = StyleSheet.create({
    container: {
        width: width - 30,
        marginBottom: 20,
        flexDirection: 'row',
        alignItems: 'center'
    }
});