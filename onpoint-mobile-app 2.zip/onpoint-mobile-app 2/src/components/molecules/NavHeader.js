import React from 'react';
import { TouchableOpacity, Image, StyleSheet, Platform } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';

const is_iOS = (Platform.OS === 'ios');

const DrawerIcon = (props) => {
    return (
        <TouchableOpacity onPress={() => {props.screenProps.navigation.navigate('DrawerOpen');}}>
            <Image style={s.navHeaderIcon} source={require('icons/menu_wh.png')} />
        </TouchableOpacity>
    );
};

export default (props) => {
    return (
        <LinearGradient
            colors={[ '#ED1651', '#5B449B' ]}
            start={{ x: 0, y: .5 }} end={{ x: 1, y: .5 }}
            style={s.navHeaderContainer}>
            <Image style={s.navHeaderIcon} source={require('icons/logo_wh.png')} />
            {!props.subRoute ? <DrawerIcon {...props} /> : null}
        </LinearGradient>
    );
};

const s = StyleSheet.create({
    navHeaderContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        backgroundColor: 'white',
        height: is_iOS ? 76 : 60,
        paddingTop: is_iOS ? 16 : 0,
        paddingHorizontal: 20
    },
    navHeaderIcon: {
        height: 35,
        width: 35,
        resizeMode: 'contain'
    }
});