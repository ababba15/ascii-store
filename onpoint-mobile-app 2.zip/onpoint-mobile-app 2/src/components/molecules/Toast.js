/**
 * react-native-easy-toast
 * https://github.com/crazycodeboy/react-native-easy-toast
 * Email:crazycodeboy@gmail.com
 * Blog:http://jiapenghui.com
 * @flow
 */

import React, { Component } from 'react';
import { StyleSheet, View, Animated, Dimensions, Text, ViewPropTypes } from 'react-native';
import PropTypes from 'prop-types';

export const DURATION = {
    LENGTH_LONG: 2000,
    LENGTH_SHORT: 500
};
const {height} = Dimensions.get('window');

let backed;

export default class Toast extends Component {

    constructor(props) {
        super(props);
        backed = this.props.backed;
        this.state = {
            isShow: false,
            text: '',
            opacityValue: new Animated.Value(this.props.opacity)
        };
    }
    showTimed(text, duration) {
        this.duration = duration || DURATION.LENGTH_SHORT;

        this.setState({
            isShow: true,
            text: text
        });

        Animated.timing(
            this.state.opacityValue, {
                toValue: this.props.opacity,
                duration: this.props.fadeInDuration
            }
        ).start(() => {
            this.isShow = true;
            this.close();
        });
    }

    show(text, duration) {
        this.duration = duration || DURATION.LENGTH_SHORT;

        this.setState({
            isShow: true,
            text: text
        });

        Animated.timing(
            this.state.opacityValue, {
                toValue: this.props.opacity,
                duration: this.props.fadeInDuration
            }
        ).start(() => {
            this.isShow = true;
        // this.hide();
        });
    }

    close() {
        let delay = this.duration;

        if (!this.isShow) return;
        this.timer && clearTimeout(this.timer);
        this.timer = setTimeout(() => {
            Animated.timing(
                this.state.opacityValue, {
                    toValue: 0.0,
                    duration: this.props.fadeOutDuration
                }
            ).start(() => {
                this.setState({
                    isShow: false
                });
                this.isShow = false;
            });
        }, delay);
    }

    hide() {
        if (!this.isShow) return;

        this.timer && clearTimeout(this.timer);
        this.timer = setTimeout(() => {
            Animated.timing(
                this.state.opacityValue, {
                    toValue: 0.0,
                    duration: this.props.fadeOutDuration
                }
            ).start(() => {
                this.setState({
                    isShow: false
                });
                this.isShow = false;
            });
        }, 0);
    }

    componentWillUnmount() {
        this.timer && clearTimeout(this.timer);
    }

    render() {
        let pos;
        let bgColor = backed ? '#FF48B0' : 'transparent';
        let txColor = backed ? '#fff' : '#FFB0B2';
        let bdrWidth = backed ? 1 : 0;
        switch (this.props.position) {
        case 'top':
            pos = this.props.positionValue;
            break;
        case 'center':
            pos = height / 2;
            break;
        case 'bottom':
            pos = height - this.props.positionValue;
            break;
        default:
            pos = height - this.props.positionValue;
        }
        let view = this.state.isShow ?
            <View style={[styles.container, { top: pos }]} pointerEvents='none'>
                <Animated.View style={[styles.content, { opacity: this.state.opacityValue }, { backgroundColor: bgColor, borderWidth: bdrWidth }, this.props.style]}>
                    <Text style={[{ color: txColor }, this.props.textStyle]}>
                        { this.state.text }
                    </Text>
                </Animated.View>
            </View> : null;
        return view;
    }
}



const styles = StyleSheet.create({
    container: {
        position: 'absolute',
        left: 0,
        right: 0,
        alignItems: 'center'
    },
    content: {
        backgroundColor: '#FF00C0',
        borderWidth: 0,
        paddingHorizontal: 20,
        borderRadius: 0,
        width: '100%'
        // borderColor: 'rgba(158,1,6,1)'
    },
    text: {
        fontSize: 18,
        marginVertical: 12,
        color: '#F1F4FF',
        textAlign: 'center',
        fontWeight: '400'
    }
});


Toast.propTypes = {
    ...ViewPropTypes,
    position: PropTypes.oneOf([
        'top',
        'center',
        'bottom'
    ]),
    textStyle: Text.propTypes.style,
    positionValue: PropTypes.number,
    fadeInDuration: PropTypes.number,
    fadeOutDuration: PropTypes.number,
    opacity: PropTypes.number
};

Toast.defaultProps = {
    position: 'top',
    textStyle: styles.text,
    positionValue: 26,
    fadeInDuration: 50,
    fadeOutDuration: 550,
    opacity: 1
};
