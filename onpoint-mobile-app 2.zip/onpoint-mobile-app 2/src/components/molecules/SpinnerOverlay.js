import React from 'react';
import { View, Modal, Image, StyleSheet } from 'react-native';

export default (props) => {
    return (
        <Modal
            transparent
            style={s.modal}
            animationType='fade'
            onRequestClose={() => null}
            visible={props.modalVisible}>
            <View style={s.centering}>
                <Image style={s.gif} source={require('assets/spinners/spinner.gif')} />
            </View>
        </Modal>
    );
};

const s = StyleSheet.create({
    modal: {
    },
    centering: {
        backgroundColor: 'rgba(255,255,255,0.8)',
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center'
    },
    gif: {
        width: 100,
        height: 105
    }
});