import React from 'react';
import { View, Image, StyleSheet, Dimensions, TouchableOpacity } from 'react-native';
import { Text } from 'atoms';

const { width } = Dimensions.get('screen');

export const Separator = (sectionId, rowId) => <View sectionId={sectionId} key={rowId} style={s.separator} />;

export default (props) => (
    <TouchableOpacity style={s.container} activeOpacity={.8} onPress={props.onPress}>
        <View style={s.artist}>
            <Text sz={22} style={s.artistTitle}>{props.client_username}</Text>
            <Text sz={16} style={s.artistTitle}>{props.client_email}</Text>
        </View>
        {props.is_used ?
            <Image style={s.icon} source={require('icons/green_tick.png')} /> :
            <Image style={s.icon} source={require('icons/grey_tick.png')} />
        }
    </TouchableOpacity>
);

const s = StyleSheet.create({
    container: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: 20,
        minHeight: 70,
        backgroundColor: 'black'
    },
    icon: {
        width: 40,
        height: 40
    },
    artistTitle: {
        maxWidth: width - 140
    }
});