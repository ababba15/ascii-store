import { delay } from 'redux-saga';
import { takeLatest, call, put } from 'redux-saga/effects';
import { AsyncStorage } from 'react-native';
import types from 'constants';

function* _initialActions() {
    yield put({ type: 'OVERLAY', payload: true });
    const token = yield call(AsyncStorage.getItem, 'token');

    console.log('token', token);

    if (token) {
        yield put({
            type: 'USER_LOGIN_SUCCESS',
            payload: {
                loggedIn: true
            }
        });
        yield put({
            type: 'GET_EVENTS_REQUEST'
        });
    }

    yield put({ type: 'OVERLAY', payload: false });
}


export default () => {
    return takeLatest(types.INITIAL_ACTIONS, _initialActions);
};