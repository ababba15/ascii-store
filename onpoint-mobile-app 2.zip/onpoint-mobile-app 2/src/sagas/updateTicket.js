import { takeEvery, put, select } from 'redux-saga/effects';

function* updateTicket(action) {
    const unparsed = JSON.parse(action.payload);
    const { event_id, uid } = unparsed;
    const ticketsInStore = yield select(state => state.tickets);
    let nextEventState;

    if (ticketsInStore[event_id]) {
        let evt =  yield ticketsInStore[event_id].map(ticket => {
            if (ticket.uid === uid) {
                ticket.is_used = true;
            }
            return ticket;
        });
        nextEventState = evt;
    }

    yield put({
        type: 'GET_TICKETS_SUCCESS',
        payload: { ...ticketsInStore, [event_id]: nextEventState }
    });
}


export default function() {
    return takeEvery('UPDATE_TICKET', updateTicket);
}