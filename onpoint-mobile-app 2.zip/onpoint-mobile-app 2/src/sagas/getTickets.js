import { takeEvery, call, put, select } from 'redux-saga/effects';
import { AsyncStorage } from 'react-native';
import { ticketsAPI } from 'api';


function* getTickets(action) {
    yield put({ type: 'OVERLAY', payload: true });
    const eventId = action.payload;
    const token = yield call(AsyncStorage.getItem, 'token');
    const response = yield call(ticketsAPI.get, { id: eventId }, { Authorization: 'Token ' + token });
    const ticketsInStore = yield select(state => state.tickets);

    console.log('getTickets', response);

    if (response.results) {
        yield put({
            type: 'GET_TICKETS_SUCCESS',
            payload: { [eventId]: response.results, ...ticketsInStore }
        });
    }
    yield put({ type: 'OVERLAY', payload: false });
}


export default function() {
    return takeEvery('GET_TICKETS_REQUEST', getTickets);
}