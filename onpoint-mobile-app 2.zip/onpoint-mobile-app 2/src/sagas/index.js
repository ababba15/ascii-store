import { all } from 'redux-saga/effects';
import userLogin from './userLogin';
import initialActions from './initialActions';
import getEvents from './getEvents';
import getTickets from './getTickets';
import updateTicket from './updateTicket';
import socket from './socket';

export default function* () {
    yield all([
        userLogin(),
        initialActions(),
        getEvents(),
        getTickets(),
        socket(),
        updateTicket()
    ]);
}