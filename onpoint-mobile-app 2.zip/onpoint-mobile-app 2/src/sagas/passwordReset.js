// import { takeLatest, put, call } from 'redux-saga/effects';
// import { AsyncStorage } from 'react-native';
// import { loginAPI } from 'api';
// import types from 'constants';

// function* userLogin(action) {
//     const { checked, email, password } = action.payload;
//     yield put({
//         type: types.SPINNER,
//         payload: {
//             loginButton: true
//         }
//     });

//     const response = yield call(loginAPI.post, {
//         email,
//         password
//     });

//     const token = response.auth_token;

//     if (token) {
//         if (checked) {
//             yield AsyncStorage.setItem('token', token);
//         }

//         yield put({
//             type: 'USER_LOGIN_SUCCESS',
//             payload: {
//                 loggedIn: true
//             }
//         });
//     }

//     yield put({
//         type: types.SPINNER,
//         payload: {
//             loginButton: false
//         }
//     });
// }

// export default function() {
//     return takeLatest('USER_LOGIN_REQUEST', userLogin);
// }