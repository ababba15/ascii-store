import { takeLatest, call, cps, put, select } from 'redux-saga/effects';
// import { eventChannel } from 'redux-saga';
import store from 'store';
import { AsyncStorage } from 'react-native';
import ReconnectingWebSocket from 'reconnecting-websocket';

let ws;

function* socket(action) {
    const update = (e) => {
        store.dispatch({
            type: 'UPDATE_TICKET',
            payload: e.data
        });
    };

    const token = yield call(AsyncStorage.getItem, 'token');

    if (action.connect) {
        ws = new ReconnectingWebSocket('wss://onpoint.co.nz/ws/sync_ticket?token=' + token);
        // ws = new ReconnectingWebSocket('wss://onpoint.mitri4.pro/ws/sync_ticket?token=' + token);
        ws.addEventListener('open', (e) => {
            console.log('socket open');
        });
        ws.addEventListener('error', (e) => {
            console.log('socket error -> message', e.message);
        });
        // ws.addEventListener('close', (e) => {
        //     // alert('connection closed, reconnecting...');
        //     // console.log('socket close -> reason', e.reason);
        // });
        ws.addEventListener('message', (e) => {
            console.log('socket message:', e.data);
            update(e);
        });
    }

    if (action.sendMessage) {
        ws.send(`{"token":"${token}","uid":"${action.payload.uid}"}`);
    }

    if (action.close) {
        ws.close();
    }
}


export default function() {
    return takeLatest('SOCKET', socket);
}



// import { take, put, call, apply, fork, takeLatest } from 'redux-saga/effects';
// import { eventChannel, delay } from 'redux-saga';
// import { AsyncStorage } from 'react-native';
// import ReconnectingWebSocket from 'reconnecting-websocket';

// const createWebSocketConnection = (token) => {
//     return new WebSocket('ws://dev.onpoint.huskyjam.com/ws/sync_ticket?token=' + token);
// };

// function createSocketChannel(socket) {
//     return eventChannel(emit => {

//         console.log(socket);
//         const messageHandler = (event) => {
//             console.log(event.data);
//             emit(event.payload);
//         };


//         socket.on('message', messageHandler);

//         const unsubscribe = () => {
//             socket.off('message', messageHandler);
//         };

//         return unsubscribe;
//     });
// }

// function* pong(socket) {
//     yield call(delay, 5000);
//     yield apply(socket, socket.emit, ['pong']);
// }

// function* watchOnMessages() {
//     const token = yield call(AsyncStorage.getItem, 'token');
//     const socket = yield call(createWebSocketConnection, token);
//     const socketChannel = yield call(createSocketChannel, socket);

//     while (true) {
//         const payload = yield take(socketChannel);
//         yield put({ type: 'INCOMING_PONG_PAYLOAD', payload });
//         yield fork(pong, socket);
//     }
// }

// export default function() {
//     return takeLatest('SOCKET', watchOnMessages);
// }
