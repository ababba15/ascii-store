import { takeLatest, call, put, all, select } from 'redux-saga/effects';
import { delay } from 'redux-saga';
import { AsyncStorage } from 'react-native';
import { eventsAPI } from 'api';

function* getEvents() {
    yield put({ type: 'OVERLAY', payload: true });
    const token = yield call(AsyncStorage.getItem, 'token');
    const response = yield call(eventsAPI.get, null, { Authorization: 'Token ' + token });

    console.log('getEvents', response);

    if (response.results) {
        yield put({
            type: 'GET_EVENTS_SUCCESS',
            payload: response.results
        });

        yield call(delay, 3000);

        yield put({
            type: 'SOCKET',
            connect: true
        });
    }

    yield put({ type: 'OVERLAY', payload: false });
}


export default function() {
    return takeLatest('GET_EVENTS_REQUEST', getEvents);
}