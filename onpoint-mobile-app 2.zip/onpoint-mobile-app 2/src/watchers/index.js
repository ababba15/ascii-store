import store from 'store';
import watch from 'redux-watch';

let _watchToken = watch(store.getState, 'storeToken');
export const watchToken = store.subscribe(_watchToken((newVal, oldVal, objectPath) => {
    return newVal;
}));


let _watchLoggedIn = watch(store.getState, 'loggedIn');
export const watchLoggedIn = store.subscribe(_watchLoggedIn((newVal, oldVal, objectPath) => {
    return newVal;
}));
